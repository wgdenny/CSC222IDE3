public class HybridEmployee extends Employee{

    private int daysAtWork;
    private int daysAtHome;
    private double salaryPerHour;
    private int wifiSpeed;

    public int getDaysAtWork() { return daysAtWork;}
    public int getDaysAtHome() { return daysAtHome;}
    public double getSalaryPerHour() { return salaryPerHour;}
    public int getWifiSpeed() { return wifiSpeed;}
    public void setDaysAtWork(int daWork) {daysAtWork = daWork;}
    public void setDaysAtHome(int daHome) {daysAtHome = daHome;}
    public void setSalaryPerHour(double hrSal) {salaryPerHour = hrSal;}
    public void setWifiSpeed(int wifi) {wifiSpeed = wifi;}







}

